AEDRYX BRAND ASSET PACK
=======================

This pack contains two kinds of assets:

1. CLEAN / REUSABLE BRAND ASSETS
   - Vector logo mark and lockups (SVG)
   - Transparent logo PNGs
   - App icon, favicons, common icon sizes
   - Color tokens and web CSS/JSON
   - Typography guidance
   - Social / OG assets
   - HTML brand book

2. EXACT VISUAL CROPS FROM THE APPROVED BRAND BOARD
   - Primary logo concept
   - Secondary/horizontal logo concept
   - App icon concept
   - Hero concept
   - Color palette panel
   - Typography panel
   - Brand keyword panel
   - Product/interface concept
   - Architectural signage concept
   - Footer brand statement

IMPORTANT
---------
The interface and environmental imagery in the board are concept visuals.
For product implementation, use the clean SVG/PNG logo system and the provided
color / typography tokens. Font files are not bundled; use Sora and Inter from
your normal licensed web-font/font source.

CORE BRAND
----------
Name: AEDRYX
Tagline: Intelligence for the built world.
Hero: Build the physical world with intelligence.

COLORS
------
Abyss Navy      #0B1F3B
Aedryx Blue     #00C2FF
Signal Amber    #FF9500
Concrete White  #F8FAFC
Steel Gray      #94A3B8
Graphite        #1E293B

TYPOGRAPHY
----------
Headings: Sora
Body / UI: Inter

KEYWORDS
--------
Spatial / Autonomous / Precise / Industrial / Intelligent / Reliable
