# AEDRYX Typography

## Primary heading font
**Sora** — use for H1–H4, product headlines, large numbers, navigation emphasis, and major campaign statements.

Recommended weights:
- 700 / Bold — hero headlines
- 600 / Semibold — section headings
- 500 / Medium — compact interface labels

## Body + interface font
**Inter** — use for body copy, forms, dashboards, tables, metadata, UI labels, and long-form text.

Recommended weights:
- 600 — buttons and emphasized UI
- 500 — labels and navigation
- 400 — body copy

Font files are intentionally not bundled in this asset pack. Install Sora and Inter from your normal licensed font source or web-font provider.
